-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 13, 2023 at 10:35 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `a109`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `uname` varchar(55) NOT NULL,
  `pass` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `uname`, `pass`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `donor`
--

CREATE TABLE `donor` (
  `id` int(11) NOT NULL,
  `dname` varchar(55) NOT NULL,
  `fname` varchar(55) NOT NULL,
  `addr` varchar(55) NOT NULL,
  `dob` varchar(55) NOT NULL,
  `gender` varchar(55) NOT NULL,
  `bgroup` varchar(55) NOT NULL,
  `organ` varchar(55) NOT NULL,
  `occu` varchar(55) NOT NULL,
  `email` varchar(55) NOT NULL,
  `cno` varchar(55) NOT NULL,
  `st` varchar(33) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `donor`
--

INSERT INTO `donor` (`id`, `dname`, `fname`, `addr`, `dob`, `gender`, `bgroup`, `organ`, `occu`, `email`, `cno`, `st`) VALUES
(2, 'Raja', 'Vinoth', 'Ngl', '45', 'Male', 'O+', 'Kidneys', 'SD', 'linocoasta@gmail.com', '9488870339', 'donated');

-- --------------------------------------------------------

--
-- Table structure for table `recipient`
--

CREATE TABLE `recipient` (
  `id` int(11) NOT NULL,
  `rname` varchar(55) NOT NULL,
  `fname` varchar(55) NOT NULL,
  `addr` varchar(55) NOT NULL,
  `dob` varchar(55) NOT NULL,
  `gender` varchar(55) NOT NULL,
  `bgroup` varchar(55) NOT NULL,
  `organ` varchar(55) NOT NULL,
  `occu` varchar(55) NOT NULL,
  `email` varchar(55) NOT NULL,
  `cno` varchar(55) NOT NULL,
  `uname` varchar(55) NOT NULL,
  `pass` varchar(55) NOT NULL,
  `st` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `recipient`
--

INSERT INTO `recipient` (`id`, `rname`, `fname`, `addr`, `dob`, `gender`, `bgroup`, `organ`, `occu`, `email`, `cno`, `uname`, `pass`, `st`) VALUES
(2, 'Arun', 'Thankam', 'kkkk', '22', 'Male', 'O+', 'Kidneys', 'SD', 'demo2020itech@gmail.com', '969789789', 'sss', 'sss', '-'),
(3, 'Vinoth', 'rajesh', 'Karugal', '34', 'Male', 'O+', 'Kidneys', 'SD', 'fff212@gmail.com', '9488870339', 'ddd', 'ddd', '-'),
(4, 'Arumugam', 'Ram', 'Chennai', '56', 'Male', 'O+', 'Kidneys', 'SD', 'sureshmca8@gmail.com', '9488870339', 'fff', 'fff', '-'),
(5, 'Rajesh', 'Prem', 'Salem', '33', 'Male', 'O+', 'Kidneys', 'SD', 'linocoasta@gmail.com', '8798965767', 'mmm', 'mmm', '-'),
(6, 'Suresh', 'PPM', 'Kalluvilai', '20', 'Male', 'O+', 'Kidneys', 'Manager', 'sureshmca8@gmail.com', '9488870339', 'qqq', 'qqq', 'donated');

-- --------------------------------------------------------

--
-- Table structure for table `transplant`
--

CREATE TABLE `transplant` (
  `id` int(11) NOT NULL,
  `dname` varchar(55) NOT NULL,
  `rname` varchar(55) NOT NULL,
  `bgroup` varchar(55) NOT NULL,
  `organ` varchar(55) NOT NULL,
  `dt1` varchar(55) NOT NULL,
  `dt2` varchar(55) NOT NULL,
  `st` varchar(55) NOT NULL,
  `rid` varchar(33) NOT NULL,
  `did` varchar(33) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `donor`
--
ALTER TABLE `donor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `recipient`
--
ALTER TABLE `recipient`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transplant`
--
ALTER TABLE `transplant`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `donor`
--
ALTER TABLE `donor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `recipient`
--
ALTER TABLE `recipient`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `transplant`
--
ALTER TABLE `transplant`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
