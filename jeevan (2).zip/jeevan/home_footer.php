<div class="footer">
        <div class="copyright text-center">
        <p> Copyright ©  <?php echo date('Y'); ?> Aakash Foundation. All Rights Reserved</p>
        </div>
        </div>
        
    </div>
    </form>
</body>
</html>
