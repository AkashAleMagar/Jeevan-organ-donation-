<?php
date_default_timezone_set("Asia/Calcutta"); 
$databaseHost = 'localhost';
$databaseName = 'od';
$databaseUsername = 'root';
$databasePassword = '';

$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 
 
?>
